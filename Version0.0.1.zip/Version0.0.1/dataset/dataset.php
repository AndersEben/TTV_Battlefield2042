<?php

$buffer_file = 'justin.txt';

$buffer = fopen($buffer_file, 'r+b');
$buffer_data = stream_get_contents($buffer);

echo $buffer_data;

?>